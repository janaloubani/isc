package com.cargo.api.request;

import lombok.Getter;

@Getter
public class BookingStatusRequest {
    private String userResponse;
}
